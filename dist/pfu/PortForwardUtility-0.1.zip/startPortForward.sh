#!/bin/sh

JAR_FILE=PortForwardUtility-0.0.1-SNAPSHOT-jar-with-dependencies.jar
CONFIG_FILE=~/forward.conf

pushd `dirname $0`
java -jar $JAR_FILE $CONFIG_FILE
popd

